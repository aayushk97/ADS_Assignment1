#include <iostream>
#include "md5.h"

using namespace std;

int main(){
	cout << "md5 of aayush is " <<md5("aayush")<<endl;
	return 0;
}
